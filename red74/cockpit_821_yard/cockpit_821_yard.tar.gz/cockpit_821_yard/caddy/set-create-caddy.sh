#!/usr/bin/env bash
set -euo pipefail

source .env
echo ${cadypass}; echo ${cadyuser} 

# === CONFIG ===
USERNAME=${cadyuser}
PASSWORD=${cadypass}   # You can override via env: PASSWORD="..." ./setup-cockpit-caddy.sh
PORT="8085"           # Caddy listens here; cloudflared points to this

# === DIRECTORY SETUP ===
mkdir -p cockpit-caddy
cd cockpit-caddy

echo "[+] Creating directory: $(pwd)"

# === GENERATE BCRYPT PASSWORD HASH ===
echo "[+] Generating bcrypt hash for Caddy Basic Auth..."
HASH=$(docker run --rm caddy:alpine caddy hash-password --plaintext "$PASSWORD")

echo "[+] Hash generated."


# === GENERATE BCRYPT PASSWORD HASH ===
echo "[+] Generating bcrypt hash..."
# We use -n to strip the newline to ensure it fits on one line in the Caddyfile
HASH=$(docker run --rm caddy:alpine caddy hash-password --plaintext "$PASSWORD" | tr -d '\n\r')

echo $HASH


# === CREATE CADDYFILE ===
# Use printf to safely write the variable without shell expansion side-effects
printf "{\n    auto_https off\n}\n:%s {\n    basic_auth {\n        %s %s\n    }\n    reverse_proxy 127.0.0.1:9090\n}\n" \
    "$PORT" "$USERNAME" "$HASH" > Caddyfile



echo "[+] Caddyfile created."

# === CREATE DOCKER COMPOSE FILE ===
cat > docker-compose.yml <<EOF
version: "3.9"

services:
  cockpit-caddy:
    image: caddy:alpine
    container_name: cockpit-caddy
    restart: unless-stopped
    network_mode: host
    volumes:
      - ./Caddyfile:/etc/caddy/Caddyfile:ro
EOF

echo "[+] docker-compose.yml created."

# === SUMMARY ===
echo
echo "=========================================="
echo " Caddy reverse proxy setup complete"
echo "=========================================="
echo "Directory: $(pwd)"
echo "Username:  ${USERNAME}"
echo "Password:  ${PASSWORD}"
echo "Port:      ${PORT}"
echo
echo "Start the proxy with:"
echo "  docker compose up -d"
echo
echo "Cloudflare Tunnel should point to:"
echo "  http://localhost:${PORT}"
echo
echo "=========================================="

\