#!/usr/bin/env bash
set -euo pipefail

# cockpit-allow-single-user.sh
# Enforce a single system user allowed to log into Cockpit via PAM allowlist.

PAM_FILE="/etc/pam.d/cockpit"
ALLOW_FILE="/etc/cockpit/allowed-users"
BACKUP_DIR="/var/backups/cockpit-pam"
TAG="# COCKPIT_SINGLE_USER_ALLOWLIST_MANAGED"

usage() {
  cat <<EOF
Usage:
  $0 --apply <username>   Apply single-user allowlist for Cockpit
  $0 --rollback           Roll back to last PAM backup
  $0 --status             Show current allowlist and PAM state
EOF
}

ensure_root() {
  if [[ "${EUID:-$(id -u)}" -ne 0 ]]; then
    echo "This must be run as root." >&2
    exit 1
  fi
}

timestamp() {
  date +"%Y%m%d-%H%M%S"
}

backup_pam() {
  mkdir -p "$BACKUP_DIR"
  local ts
  ts="$(timestamp)"
  local backup="${BACKUP_DIR}/cockpit.pam.${ts}.bak"
  cp -a "$PAM_FILE" "$backup"
  echo "Backup created: $backup"
}

apply_allowlist() {
  local user="$1"

  if ! id "$user" &>/dev/null; then
    echo "Warning: user '$user' does not currently exist. PAM will still enforce allowlist." >&2
  fi

  mkdir -p "$(dirname "$ALLOW_FILE")"
  echo "$user" > "$ALLOW_FILE"
  chmod 0640 "$ALLOW_FILE"
  echo "Allowlist written to $ALLOW_FILE with user: $user"

  if [[ ! -f "$PAM_FILE" ]]; then
    echo "Error: PAM file $PAM_FILE does not exist." >&2
    exit 1
  fi

  if grep -q "$TAG" "$PAM_FILE"; then
    echo "Managed block already present in $PAM_FILE; not adding duplicate."
    return 0
  fi

  backup_pam

  # Build new PAM file with managed block at top
  local tmp
  tmp="$(mktemp)"
  cat > "$tmp" <<EOF
auth required pam_listfile.so onerr=fail item=user sense=allow file=${ALLOW_FILE}
${TAG}
EOF

  # Append the existing PAM file
  cat "$PAM_FILE" >> "$tmp"

  mv "$tmp" "$PAM_FILE"
  chmod 0644 "$PAM_FILE"

  echo "PAM allowlist rule injected into $PAM_FILE"
}

rollback_pam() {
  if [[ ! -d "$BACKUP_DIR" ]]; then
    echo "No backup directory found at $BACKUP_DIR" >&2
    exit 1
  fi

  local last_backup
  last_backup="$(ls -1 "${BACKUP_DIR}"/cockpit.pam.*.bak 2>/dev/null | sort | tail -n 1 || true)"

  if [[ -z "$last_backup" ]]; then
    echo "No backups found in $BACKUP_DIR" >&2
    exit 1
  fi

  cp -a "$last_backup" "$PAM_FILE"
  echo "Restored $PAM_FILE from backup: $last_backup"
}

status() {
  echo "== Allowlist file =="
  if [[ -f "$ALLOW_FILE" ]]; then
    echo "Path: $ALLOW_FILE"
    echo "Contents:"
    sed 's/^/  /' "$ALLOW_FILE"
  else
    echo "Allowlist file not found at $ALLOW_FILE"
  fi

  echo
  echo "== PAM file =="
  if [[ -f "$PAM_FILE" ]]; then
    if grep -q "$TAG" "$PAM_FILE"; then
      echo "Managed allowlist block is present in $PAM_FILE"
      echo
      echo "Managed block (first lines):"
      head -n 5 "$PAM_FILE" | sed 's/^/  /'
    else
      echo "Managed allowlist block NOT found in $PAM_FILE"
    fi
  else
    echo "PAM file not found at $PAM_FILE"
  fi

  echo
  echo "== Backups =="
  if [[ -d "$BACKUP_DIR" ]]; then
    ls -1 "$BACKUP_DIR"/cockpit.pam.*.bak 2>/dev/null || echo "No backups present."
  else
    echo "Backup directory $BACKUP_DIR does not exist."
  fi
}

main() {
  if [[ $# -lt 1 ]]; then
    usage
    exit 1
  fi

  case "$1" in
    --apply)
      if [[ $# -ne 2 ]]; then
        usage
        exit 1
      fi
      ensure_root
      apply_allowlist "$2"
      ;;
    --rollback)
      ensure_root
      rollback_pam
      ;;
    --status)
      status
      ;;
    *)
      usage
      exit 1
      ;;
  esac
}

main "$@"

