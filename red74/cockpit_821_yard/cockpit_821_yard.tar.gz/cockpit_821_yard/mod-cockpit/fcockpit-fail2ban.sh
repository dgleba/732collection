#!/usr/bin/env bash
set -euo pipefail

FILTER_FILE="/etc/fail2ban/filter.d/cockpit.conf"
JAIL_FILE="/etc/fail2ban/jail.d/cockpit.conf"
BACKUP_DIR="/var/backups/fail2ban-cockpit"
TAG="# MANAGED_BY_COCKPIT_FAIL2BAN_SCRIPT"

ensure_root() {
    if [[ $EUID -ne 0 ]]; then
        echo "This script must be run as root."
        exit 1
    fi
}

timestamp() {
    date +"%Y%m%d-%H%M%S"
}

backup_if_exists() {
    local file="$1"
    if [[ -f "$file" ]]; then
        mkdir -p "$BACKUP_DIR"
        local ts
        ts=$(timestamp)
        local backup="${BACKUP_DIR}/$(basename "$file").${ts}.bak"
        cp -a "$file" "$backup"
        echo "Backup created: $backup"
    fi
}

write_filter() {
    backup_if_exists "$FILTER_FILE"

    cat > "$FILTER_FILE" <<EOF
$TAG
[Definition]

failregex = ^.*cockpit-ws.*pam_unix\\(cockpit:auth\\): authentication failure.*rhost=<HOST>.*\$
            ^.*cockpit-ws.*pam_listfile\\(cockpit:auth\\): Refused user.*rhost=<HOST>.*\$
            ^.*cockpit-ws.*Login failed for user.*from <HOST>.*\$

ignoreregex =
EOF

    chmod 0644 "$FILTER_FILE"
    echo "Wrote filter: $FILTER_FILE"
}

write_jail() {
    backup_if_exists "$JAIL_FILE"

    cat > "$JAIL_FILE" <<EOF
$TAG
[cockpit]
enabled = true
backend = systemd
filter = cockpit
port = 9090
maxretry = 4
findtime = 600
bantime = 3600
banaction = iptables-multiport
logpath = journalctl
EOF

    chmod 0644 "$JAIL_FILE"
    echo "Wrote jail: $JAIL_FILE"
}

reload_fail2ban() {
    echo "Reloading Fail2Ban..."
    systemctl restart fail2ban
    echo "Fail2Ban reloaded."
}

main() {
    ensure_root
    write_filter
    write_jail
    reload_fail2ban

    echo
    echo "Done. Check status with:"
    echo "  fail2ban-client status cockpit"
}

main


