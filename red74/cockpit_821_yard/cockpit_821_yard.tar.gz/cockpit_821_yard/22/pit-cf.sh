#!/usr/bin/env bash
set -euo pipefail

HOSTNAME="cpit.daveg.win"
SERVICE_URL="http://localhost:9090"
CLOUDFLARED_DIR="/etc/cloudflared"
CONFIG="$CLOUDFLARED_DIR/config.yml"

echo "Detecting Cloudflare Tunnel container..."

CONTAINER=$(docker ps --format '{{.Names}}' | grep 'cftunnel' | grep 'red74' || true)

if [[ -z "$CONTAINER" ]]; then
    echo "ERROR: No Cloudflare Tunnel container found for project 'red74'."
    echo "Available tunnel containers:"
    docker ps --format '{{.Names}}' | grep 'cftunnel' || true
    exit 1
fi

echo "Using container: $CONTAINER"

mkdir -p "$CLOUDFLARED_DIR"

echo "Extracting tunnel ID from inside container..."
TUNNEL_ID=$(docker exec "$CONTAINER" sh -c "cloudflared tunnel list 2>/dev/null | awk 'NR>1 {print \$1; exit}'")

if [[ -z "$TUNNEL_ID" ]]; then
    echo "ERROR: Could not detect tunnel ID inside container."
    exit 1
fi

echo "Tunnel ID: $TUNNEL_ID"

echo "Building/Updating config at: $CONFIG"

if [[ ! -f "$CONFIG" ]]; then
    cat > "$CONFIG" <<EOF
tunnel: $TUNNEL_ID
credentials-file: $CLOUDFLARED_DIR/$TUNNEL_ID.json

ingress:
  - hostname: $HOSTNAME
    service: $SERVICE_URL
  - service: http_status:404
EOF
else
    if grep -q "$HOSTNAME" "$CONFIG"; then
        echo "Updating existing hostname entry..."
        sed -i "/hostname: $HOSTNAME/{n;s|service:.*|service: $SERVICE_URL|}" "$CONFIG"
    else
        echo "Appending new ingress rule..."
        sed -i "/ingress:/a\  - hostname: $HOSTNAME\n    service: $SERVICE_URL" "$CONFIG"
    fi
fi

echo "Copying config into container..."
docker cp "$CONFIG" "$CONTAINER:/etc/cloudflared/config.yml"

echo "Validating config inside container..."
docker exec "$CONTAINER" cloudflared tunnel ingress validate /etc/cloudflared/config.yml

echo "Restarting Cloudflare Tunnel container..."
docker restart "$CONTAINER" >/dev/null

echo
echo "Cockpit is now published through Cloudflare Tunnel."
echo "Access it at:"
echo "  https://$HOSTNAME"
echo
echo "To verify routing:"
echo "  docker exec $CONTAINER cloudflared tunnel ingress list"
