#!/usr/bin/env bash
set -euo pipefail

HOSTNAME="cpit.daveg.win"
SERVICE_URL="http://localhost:9090"
CLOUDFLARED_DIR="/etc/cloudflared"
CONFIG="$CLOUDFLARED_DIR/config.yml"

echo "=== STEP 1: Reinstalling Cockpit ==="

sudo apt update
sudo apt install -y cockpit cockpit-system cockpit-ws cockpit-bridge

sudo systemctl daemon-reload
sudo systemctl enable --now cockpit.socket

echo "Checking Cockpit status..."
if systemctl is-active --quiet cockpit.socket; then
    echo "✔ Cockpit socket is active"
else
    echo "❌ Cockpit socket failed to start"
    exit 1
fi

echo "Testing local Cockpit endpoint..."
if curl -sk --max-time 3 https://localhost:9090/login >/dev/null 2>&1; then
    echo "✔ Cockpit is responding locally"
else
    echo "❌ Cockpit is NOT responding locally"
    exit 1
fi

echo
echo "=== STEP 2: Publishing Cockpit to Cloudflare Tunnel ==="

echo "Detecting Cloudflare Tunnel container..."
CONTAINER=$(docker ps --format '{{.Names}}' | grep 'cftunnel' | grep 'red74' || true)

if [[ -z "$CONTAINER" ]]; then
    echo "❌ No Cloudflare Tunnel container found for project 'red74'"
    exit 1
fi

echo "Using container: $CONTAINER"

mkdir -p "$CLOUDFLARED_DIR"

echo "Extracting tunnel ID from inside container..."
TUNNEL_ID=$(docker exec "$CONTAINER" sh -c "cloudflared tunnel list 2>/dev/null | awk 'NR>1 {print \$1; exit}'")

if [[ -z "$TUNNEL_ID" ]]; then
    echo "❌ Could not detect tunnel ID inside container"
    exit 1
fi

echo "Tunnel ID: $TUNNEL_ID"

echo "Building/Updating config at: $CONFIG"

if [[ ! -f "$CONFIG" ]]; then
    cat > "$CONFIG" <<EOF
tunnel: $TUNNEL_ID
credentials-file: $CLOUDFLARED_DIR/$TUNNEL_ID.json

ingress:
  - hostname: $HOSTNAME
    service: $SERVICE_URL
  - service: http_status:404
EOF
else
    if grep -q "$HOSTNAME" "$CONFIG"; then
        echo "Updating existing hostname entry..."
        sed -i "/hostname: $HOSTNAME/{n;s|service:.*|service: $SERVICE_URL|}" "$CONFIG"
    else
        echo "Appending new ingress rule..."
        sed -i "/ingress:/a\  - hostname: $HOSTNAME\n    service: $SERVICE_URL" "$CONFIG"
    fi
fi

echo "Copying config into container..."
docker cp "$CONFIG" "$CONTAINER:/etc/cloudflared/config.yml"

echo "Validating config inside container..."
docker exec "$CONTAINER" cloudflared tunnel ingress validate /etc/cloudflared/config.yml

echo "Restarting Cloudflare Tunnel container..."
docker restart "$CONTAINER" >/dev/null

echo
echo "=== STEP 3: Verifying Cloudflare Route ==="

echo "1) Checking DNS..."
DNS_IP=$(dig +short "$HOSTNAME" @1.1.1.1 || true)
if [[ -z "$DNS_IP" ]]; then
    echo "❌ DNS lookup failed — hostname not published in Cloudflare"
else
    echo "✔ DNS resolves to: $DNS_IP"
fi
echo

echo "2) Checking Cloudflare Tunnel ingress..."
INGRESS=$(docker exec "$CONTAINER" cloudflared tunnel ingress list 2>/dev/null || true)
if echo "$INGRESS" | grep -q "$HOSTNAME"; then
    echo "✔ Ingress rule found:"
    echo "$INGRESS" | grep "$HOSTNAME"
else
    echo "❌ Ingress rule NOT found for $HOSTNAME"
fi
echo

echo "3) Checking local Cockpit service..."
if curl -sk --max-time 3 https://localhost:9090/login >/dev/null 2>&1; then
    echo "✔ Cockpit is responding locally"
else
    echo "❌ Cockpit is NOT responding locally"
fi
echo

echo "4) Checking external HTTPS route..."
if curl -sk --max-time 5 "https://$HOSTNAME/login" >/dev/null 2>&1; then
    echo "✔ External HTTPS route is active: https://$HOSTNAME"
else
    echo "❌ External HTTPS route is NOT reachable"
fi

echo
echo "=== ALL STEPS COMPLETE ==="
