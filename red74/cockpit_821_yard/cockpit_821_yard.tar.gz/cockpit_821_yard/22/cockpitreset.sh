#!/usr/bin/env bash
set -euo pipefail

TS="$(date '+%Y%m%d-%H%M%S')"
BASE_DIR="/ap/backup/cockpit/$TS"
MANIFEST="$BASE_DIR/manifest.txt"
BACKUP_DIR="$BASE_DIR/backup"
LOGFILE="$BASE_DIR/log.txt"

mkdir -p "$BACKUP_DIR"

TARGETS=(
    # APT-installed cockpit files
    /etc/apparmor.d/cockpit-desktop
    /etc/cockpit
    /etc/fail2ban/filter.d/cockpit.conf
    /etc/fail2ban/jail.d/cockpit.conf
    /etc/issue.d/cockpit.issue
    /etc/motd.d/cockpit
    /etc/pam.d/cockpit
    /etc/systemd/system/cockpit.socket.d
    /etc/systemd/system/sockets.target.wants/cockpit.socket
    /usr/bin/cockpit-bridge
    /usr/lib/cockpit
    /usr/lib/python3/dist-packages/cockpit
    /usr/lib/python3/dist-packages/cockpit-352.dist-info
    /usr/lib/systemd/system/cockpit*
    /usr/lib/tmpfiles.d/cockpit-ws.conf
    /usr/lib/x86_64-linux-gnu/security/pam_cockpit_cert.so
    /usr/share/cockpit
    /usr/share/doc/cockpit*
    /usr/share/icons/hicolor/*/cockpit*
    /usr/share/lintian/overrides/cockpit*
    /usr/share/man/man1/cockpit*
    /usr/share/man/man5/cockpit.conf.5.gz
    /usr/share/man/man8/cockpit*
    /usr/share/metainfo/org.cockpit_project*
    /usr/share/polkit-1/actions/org.cockpit-project*
    /var/backups/cockpit-pam
    /var/lib/dpkg/info/cockpit*
    /var/lib/swcatalog/icons/*/cockpit*
    /var/lib/systemd/deb-systemd-helper-enabled/cockpit*

    # Your custom reverse-proxy stacks
    #/ap/dkr/732collection/red74/cockpit_821_yard
)

echo "Cockpit Reset Manifest - $(date)" > "$MANIFEST"
echo "----------------------------------------" >> "$MANIFEST"

# Build manifest
for path in "${TARGETS[@]}"; do
    for item in $path; do
        if [[ -e "$item" ]]; then
            echo "$item" >> "$MANIFEST"
        fi
    done
done

echo "Manifest created at: $MANIFEST"
echo "Backup directory: $BACKUP_DIR"
echo "Log file: $LOGFILE"
echo

echo "Starting backup (no deletion yet)..."
echo "Cockpit Reset Log - $(date)" >> "$LOGFILE"
echo "----------------------------------------" >> "$LOGFILE"

# Backup everything listed
while IFS= read -r item; do
    if [[ -e "$item" ]]; then
        REL_PATH="${item#/}"
        DEST="$BACKUP_DIR/$REL_PATH"

        echo "Backing up: $item -> $DEST"
        echo "$(date '+%F %T') BACKUP $item -> $DEST" >> "$LOGFILE"

        mkdir -p "$(dirname "$DEST")"
        cp -a "$item" "$DEST"
    fi
done < "$MANIFEST"

echo
echo "Backup complete."
echo "All data stored in: $BASE_DIR"
echo

# NOW ask to delete
read -r -p "Backup successful. Delete original files now? (yes/no): " CONFIRM

if [[ "$CONFIRM" != "yes" ]]; then
    echo "Aborted after backup. No files deleted."
    exit 0
fi

echo "Deleting files..."

# Delete everything listed
while IFS= read -r item; do
    if [[ -e "$item" ]]; then
        echo "Deleting: $item"
        echo "$(date '+%F %T') DELETE $item" >> "$LOGFILE"
        rm -rf "$item"
    fi
done < "$MANIFEST"

echo
echo "Deletion complete."
echo "Backup + logs stored in: $BASE_DIR"
