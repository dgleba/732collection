#!/usr/bin/env bash
set -euo pipefail

HOSTNAME="cpit.daveg.win"
CONTAINER=$(docker ps --format '{{.Names}}' | grep 'cftunnel' | grep 'red74' || true)

echo "=== Cloudflare Cockpit Route Verification ==="
echo "Hostname: $HOSTNAME"
echo

if [[ -z "$CONTAINER" ]]; then
    echo "ERROR: Cloudflare Tunnel container not found (expected red74 project)."
    exit 1
fi

echo "Using Cloudflare Tunnel container: $CONTAINER"
echo

# 1. DNS Check
echo "1) Checking DNS resolution..."
DNS_IP=$(dig +short "$HOSTNAME" @1.1.1.1 || true)

if [[ -z "$DNS_IP" ]]; then
    echo "❌ DNS lookup failed — hostname not published in Cloudflare."
else
    echo "✔ DNS resolves to: $DNS_IP"
fi
echo

# 2. Cloudflare Tunnel Ingress Check
echo "2) Checking Cloudflare Tunnel ingress rules inside container..."
INGRESS=$(docker exec "$CONTAINER" cloudflared tunnel ingress list 2>/dev/null || true)

if echo "$INGRESS" | grep -q "$HOSTNAME"; then
    echo "✔ Ingress rule found:"
    echo "$INGRESS" | grep "$HOSTNAME"
else
    echo "❌ Ingress rule NOT found for $HOSTNAME"
fi
echo

# 3. Local Cockpit Check
echo "3) Checking local Cockpit service on port 9090..."
if curl -sk --max-time 3 https://localhost:9090/login >/dev/null 2>&1; then
    echo "✔ Cockpit is responding locally on https://localhost:9090"
else
    echo "❌ Cockpit is NOT responding locally"
fi
echo

# 4. External HTTPS Check
echo "4) Checking external access through Cloudflare..."
if curl -sk --max-time 5 "https://$HOSTNAME/login" >/dev/null 2>&1; then
    echo "✔ External HTTPS route is active: https://$HOSTNAME"
else
    echo "❌ External HTTPS route is NOT reachable"
fi
echo

echo "=== Verification Complete ==="
