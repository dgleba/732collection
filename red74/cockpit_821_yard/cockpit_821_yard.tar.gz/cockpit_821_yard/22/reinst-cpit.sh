#!/usr/bin/env bash
set -euo pipefail

echo "Updating APT..."
sudo apt update

echo "Installing minimal Cockpit..."
sudo apt install -y cockpit

echo "Enabling cockpit.socket..."
sudo systemctl enable --now cockpit.socket

echo "Verifying status..."
systemctl status cockpit.socket --no-pager

echo
echo "Cockpit minimal install complete."
echo "Local access: https://localhost:9090"
echo "If behind Cloudflare Tunnel, use your published hostname."

