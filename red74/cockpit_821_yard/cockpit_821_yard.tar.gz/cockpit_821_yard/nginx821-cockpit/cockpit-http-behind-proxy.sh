#!/usr/bin/env bash

# config cockpit for cftunnel > docker cftunnel > nginx proxy > cockpit nontls

set -euo pipefail

OVERRIDE_DIR="/etc/systemd/system/cockpit.socket.d"
OVERRIDE_FILE="${OVERRIDE_DIR}/http-listen.conf"

ensure_root() {
  if [[ "${EUID:-$(id -u)}" -ne 0 ]]; then
	echo "This must be run as root." >&2
	exit 1
  fi
}

write_override() {
  mkdir -p "$OVERRIDE_DIR"

  cat > "$OVERRIDE_FILE" <<EOF
# Managed by cockpit-http-behind-proxy.sh
[Socket]
ListenStream=
ListenStream=9090
EOF

  echo "Wrote systemd override: $OVERRIDE_FILE"
}

reload_systemd() {
  echo "Reloading systemd daemon..."
  systemctl daemon-reload
}

restart_cockpit() {
  echo "Disabling cockpit-tls..."
  systemctl stop cockpit-tls || true
  systemctl disable cockpit-tls || true

  echo "Restarting cockpit.socket..."
  systemctl restart cockpit.socket
}

validate_port() {
  echo "Validating that Cockpit is listening on 9090 (HTTP)..."

  # Give systemd a moment to bind the socket
  sleep 2

  if ! ss -ltn | grep -q ':9090 '; then
	echo "ERROR: Nothing is listening on port 9090." >&2
	systemctl status cockpit.socket --no-pager || true
	exit 1
  fi

  # Try a simple HTTP GET; we expect some HTTP-ish response, not TLS.
  if command -v curl >/dev/null 2>&1; then
	echo "Probing http://127.0.0.1:9090 ..."
	if curl -sS -o /dev/null -D - http://127.0.0.1:9090/ 2>/dev/null; then
	  echo "HTTP probe succeeded on 9090."
	else
	  echo "WARNING: curl probe failed; Cockpit might still be speaking TLS or not ready." >&2
	fi
  else
	echo "curl not found; skipping HTTP probe."
  fi
}

main() {
  ensure_root
  write_override
  reload_systemd
  restart_cockpit
  validate_port

  echo
  echo "Done."
  echo "Cockpit is now expected to listen on plain HTTP at port 9090."
  echo "Use your reverse proxy (NGINX/Cloudflare Tunnel) to provide TLS."
}

main "$@"

