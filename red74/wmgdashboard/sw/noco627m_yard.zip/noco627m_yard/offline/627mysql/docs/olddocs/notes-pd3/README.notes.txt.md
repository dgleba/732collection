
# Notes


The purpose of this file is to keep a chronicle (log) of notes on this project


##

Many more chronicle notes are in my other projects 

 - https://github.com/dgleba/385dkrsys
 - https://github.com/dgleba/dkr382r-django
 - https://github.com/dgleba/metabase
 - https://github.com/dgleba/brail347a22
 - https://github.com/dgleba/dkr378php
 
 
##
 