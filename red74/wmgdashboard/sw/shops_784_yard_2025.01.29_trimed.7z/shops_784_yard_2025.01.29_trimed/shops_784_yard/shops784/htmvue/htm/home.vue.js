export default {
	template: "<div><h1>Home</h1><p>This is home page</p></div>"
};

