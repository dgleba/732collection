import json
from django.shortcuts import render, get_object_or_404, redirect
from django.http import JsonResponse
from .models import Survey, Answer, QuestionAnswer, PartNumber
from .forms import DynamicForm
from django.db.models import Q
from django.urls import reverse
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse

@login_required
def display_survey(request, survey_id):
    # Retrieve the survey instance
    survey_instance = get_object_or_404(Survey, pk=survey_id)

    # Deserialize the survey structure if it's a string
    form_structure = survey_instance.structure
    if isinstance(form_structure, str):
        try:
            form_structure = json.loads(form_structure)
        except json.JSONDecodeError:
            raise ValueError(f"Invalid JSON structure for survey ID {survey_id}")

    # Extract questions from the form structure
    if isinstance(form_structure, dict) and "questions" in form_structure:
        form_structure = form_structure["questions"]

    # Create the form
    if request.method == 'POST':
        form = DynamicForm(request.POST, form_structure=form_structure, survey_id=survey_id)
        if form.is_valid():
            # Prepare the response data for the Answer model
            response_data = {}
            for field_name, user_answer in form.cleaned_data.items():
                # Skip null or empty string answers
                if user_answer is None or user_answer == "":
                    continue

                # Find the corresponding question in the survey structure
                question = next(
                    (q for q in form_structure if q.get("name") == field_name), None
                )
                if question:
                    # Add the answer to the response_data JSON
                    response_data[field_name] = {"answer": user_answer}
                    
                    # Only add issue and action_taken for yes/no questions
                    if question.get("type") == "choice":
                        issue = request.POST.get(f"issue_{field_name}")
                        action_taken = request.POST.get(f"action_{field_name}")
                        if issue:
                            response_data[field_name]["issue"] = issue
                        if action_taken:
                            response_data[field_name]["action_taken"] = action_taken

            # Save the response in the Answer model
            if response_data:
                answer_instance = Answer.objects.create(
                    survey=survey_instance,
                    response_data=response_data,
                    user=request.user 
                )
            # Save each question-answer as a separate entry in the QuestionAnswer model
            for field_name, user_answer in form.cleaned_data.items():
                # Skip null or empty string answers
                if user_answer is None or user_answer == "":
                    continue

                question = next(
                    (q for q in form_structure if q.get("name") == field_name), None
                )
                if question:
                    issue = ''
                    action_taken = ''
                    if question.get("type") == "choice":
                        issue = request.POST.get(f"issue_{field_name}")
                        action_taken = request.POST.get(f"action_{field_name}")
                    
                    status_by_admin = 'open' if issue or action_taken else 'closed'

                    QuestionAnswer.objects.create(
                        survey=survey_instance,
                        question_id=question.get("id"),
                        question_text=question.get("label"),
                        question_name=question.get("name"),
                        answer=answer_instance,
                        response=user_answer,
                        issue=issue,
                        action_taken=action_taken,
                        status_by_admin=status_by_admin,
                        user=request.user 
                    )
                    
        
            return redirect('pchart783app:pchart_survey_success')
    else:
        # Initialize an empty form for GET requests
        form = DynamicForm(form_structure=form_structure, survey_id=survey_id)

    # Render the form for both GET and POST requests (if POST fails validation)
    return render(request, 'pcharttemp/display_survey_pchart.html', {'form': form, 'survey_instance': survey_instance})

def survey_success(request):
    return render(request, 'pcharttemp/survey_success_pchart.html')

@login_required
def survey_list_pchart(request):
    # Get the search query from the request
    search_query = request.GET.get("search", "").strip()

    # Retrieve all surveys and answers
    surveys = Survey.objects.filter(user=request.user).order_by('sort_order', 'name', 'cell')
    answers = Answer.objects.filter(user=request.user).order_by('-created_at')

    if search_query:
        # Split the search query into individual terms
        search_terms = search_query.split()

        # Build Q objects to match all terms across name and cell fields for surveys and answers
        survey_search_q = Q()
        answer_search_q = Q()

        for term in search_terms:
            survey_search_q &= Q(name__icontains=term) | Q(cell__icontains=term)
            answer_search_q &= Q(survey__name__icontains=term) | Q(survey__cell__icontains=term)

        # Filter surveys and answers based on the combined Q objects
        surveys = surveys.filter(survey_search_q)
        answers = answers.filter(answer_search_q)

    # Slice after filtering to get the latest 5 answers
    answers = answers[:5]
    surveys = surveys[:30]
    # Handle HTMX requests separately for surveys and answers
    if request.headers.get('HX-Request'):
        target = request.GET.get('target', '')
        if target == 'answers':
            return render(request, "pcharttemp/answers_list_pchart.html", {"answers": answers})
        return render(request, "pcharttemp/survey_list_pchart.html", {"surveys": surveys})

    # For a regular page load, render the full template
    return render(request, "pcharttemp/survey_pchart.html", {
        "surveys": surveys[:30],  # Limit to 30 surveys for the full page load
        "answers": answers,
    })



@login_required
def defect_summary(request):
    from datetime import datetime, time
    
    current_time = datetime.now().time()
    today = datetime.now().date()
    
    # Define shift times
    night_start = time(0, 0)
    night_end = time(7, 0)
    day_start = time(7, 0)
    day_end = time(15, 0)
    aft_start = time(15, 0)
    aft_end = time(23, 0)
    
    # Determine current shift and time range
    if night_start <= current_time < night_end:
        shift_name = "Night"
        start_time = datetime.combine(today, night_start)
        end_time = datetime.combine(today, night_end)
    elif day_start <= current_time < day_end:
        shift_name = "Day"
        start_time = datetime.combine(today, day_start)
        end_time = datetime.combine(today, day_end)
    elif aft_start <= current_time < aft_end:
        shift_name = "Afternoon"
        start_time = datetime.combine(today, aft_start)
        end_time = datetime.combine(today, aft_end)
    else:
        shift_name = "Night"
        start_time = datetime.combine(today, night_start)
        end_time = datetime.combine(today, night_end)
    
    # Get defects for the current shift
    defect_answers = QuestionAnswer.objects.filter(
        created_at__range=(start_time, end_time),
        question_name='defect'
    ).values_list('response', flat=True)
    
    # Count defects and calculate percentages
    defect_counts = {}
    total_count = 0
    
    for defect in defect_answers:
        if defect:
            defect_counts[defect] = defect_counts.get(defect, 0) + 1
            total_count += 1
    
    # Calculate percentages and create final data structure
    defect_summary = []
    for defect, count in sorted(defect_counts.items(), key=lambda x: x[1], reverse=True):
        percentage = (count / total_count * 100) if total_count > 0 else 0
        defect_summary.append({
            'defect': defect,
            'count': count,
            'percentage': round(percentage, 1)
        })
    
    return render(request, 'pcharttemp/summary.html', {
        'defect_summary': defect_summary,
        'date': today,
        'total_count': total_count,
        'shift_name': shift_name,
        'shift_start': start_time.strftime('%H:%M'),
        'shift_end': end_time.strftime('%H:%M')
    })

def index(request):
    return render(request, 'index.html')

def autofill_action(request, field_name):
    return HttpResponse("Contacted Team Leader / Supervisor")

@login_required
def profile(request):
    return render(request, 'registration/profile.html')