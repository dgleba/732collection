from django.apps import AppConfig


class Pchart783AppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pchart783app'
