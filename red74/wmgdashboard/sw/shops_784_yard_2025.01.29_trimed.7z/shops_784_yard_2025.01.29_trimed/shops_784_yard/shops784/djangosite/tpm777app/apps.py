from django.apps import AppConfig


class Tpm777AppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tpm777app'
