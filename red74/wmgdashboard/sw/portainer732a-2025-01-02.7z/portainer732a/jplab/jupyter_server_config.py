c = get_config()  #noqa

c.ContentsManager.allow_hidden = True
