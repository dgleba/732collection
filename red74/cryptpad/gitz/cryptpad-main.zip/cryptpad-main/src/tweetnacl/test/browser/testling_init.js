window.nacl = require('../../' + (process.env.NACL_SRC || 'nacl.min.js'));
