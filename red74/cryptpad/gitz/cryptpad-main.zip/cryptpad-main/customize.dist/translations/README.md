<!--
SPDX-FileCopyrightText: 2023 XWiki CryptPad Team <contact@cryptpad.org> and contributors

SPDX-License-Identifier: AGPL-3.0-or-later
-->

# Translations

This tutorial is part of our documentation, you can find it in our how to contribute guide: https://docs.cryptpad.org/en/how_to_contribute.html#translate-cryptpad